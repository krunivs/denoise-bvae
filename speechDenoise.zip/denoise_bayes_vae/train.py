# -*- encoding: utf-8 -*-

import os
import time
import torch
import matplotlib

# only for plot file save
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from torch import optim, nn
from torch.utils.data import DataLoader
from denoise_bayes_vae.loss import elbo_loss

def train(model: nn.Module,
          optimizer: optim.Adam,
          train_loader: DataLoader,
          val_loader: DataLoader,
          device: torch.device,
          model_save_path: str,
          autodiff: bool = False,
          epochs: int = 10,
          patience: int = 3):
    """
    train model
    :param model: (nn.Module)
    :param optimizer: (optim.Adam)
    :param train_loader: (DataLoader)
    :param val_loader: (DataLoader)
    :param device: (torch.device)
    :param model_save_path: (str) model save path
    :param autodiff: (bool) is autodiff enabled? (default: False)
    :param epochs: (int) number of epochs
    :param patience: (int) The number of consecutive epochs during which the validation performance
    (e.g., validation loss) does not improve (default=3)
    :return:
    """
    if not model or not isinstance(model, nn.Module):
        raise ValueError('Invalid arg \'model\'. You must input nn.Module inherited instance.')

    if not train_loader or not isinstance(train_loader, DataLoader):
        raise ValueError('Invalid arg \'train_loader\'. You must input DataLoader type instance.')

    if not val_loader or not isinstance(val_loader, DataLoader):
        raise ValueError('Invalid arg \'val_loader\'. You must input DataLoader type instance.')

    if not device or not isinstance(device, torch.device):
        raise ValueError('Invalid arg \'device\'. You must input torch.device type instance.')

    parent_dir = os.path.dirname(model_save_path)
    model_filename = os.path.splitext(os.path.basename(model_save_path))[0]

    if not os.path.isdir(parent_dir):
        raise ValueError('Not found {} directory to save \'model {}.\'.'.format(parent_dir, model_save_path))

    loss_chart_file = os.path.join(parent_dir, 'loss_curve_{}.png'.format(model_filename))
    model.train()
    best_val_loss = float('inf')
    patience_counter = 0
    train_losses = []
    val_losses = []

    # total start time
    total_start_time = time.time()

    for epoch in range(epochs):
        epoch_start_time = time.time()  # epoch start time
        total_train_loss = 0
        '''
        KL annealing
        # kl_weight = min(1.0, epoch / 10)
        '''
        kl_weight = 1.0

        ''' Training loop '''
        for noisy, clean in train_loader:
            noisy, clean = noisy.to(device), clean.to(device)

            # normalization
            noisy = noisy / (noisy.abs().amax(dim=1, keepdim=True) + 1e-9)
            clean = clean / (clean.abs().amax(dim=1, keepdim=True) + 1e-9)

            optimizer.zero_grad()

            recon, mu, logvar = model(noisy)

            ''' 
            Scaling kl_bayesian
            # kl_bayesian = model.kl_loss() * 1e-3 
            If you make it too small, the regularization effect of kl_bayesian will disappear, 
            diluting the meaning of Bayesian VAE.
            log in elbo_loss(): recon_loss: 308.0011, kl_latent: 66.8740, kl_bayesian: 4.1215
            '''
            kl_bayesian = model.kl_loss()
            loss = elbo_loss(recon, clean, mu, logvar, kl_weight=kl_weight, kl_bayesian=kl_bayesian)

            if autodiff:    # auto differentiation mode
                grads = torch.autograd.grad(loss, model.parameters(), create_graph=False)
                for param, grad in zip(model.parameters(), grads):
                    if param.requires_grad and grad is not None:
                        param.grad = grad
            else:
                loss.backward()

            optimizer.step()
            total_train_loss += loss.item()

        avg_train_loss = total_train_loss / len(train_loader)
        train_losses.append(avg_train_loss)

        ''' Validation loop '''
        model.eval()
        total_val_loss = 0

        with torch.no_grad():
            for noisy, clean in val_loader:
                noisy, clean = noisy.to(device), clean.to(device)
                recon, mu, logvar = model(noisy)
                # kl_bayesian = model.kl_loss() * 1e-3    # scaling
                kl_bayesian = model.kl_loss()
                loss = elbo_loss(recon, clean, mu, logvar, kl_weight=kl_weight, kl_bayesian=kl_bayesian)
                total_val_loss += loss.item()

        avg_val_loss = total_val_loss / len(val_loader)
        val_losses.append(avg_val_loss)
        model.train()

        epoch_time = time.time() - epoch_start_time
        print('Epoch {}, Train Loss: {:.4f}, Validation Loss: {:.4f}, Time: {:.2f} sec'
              .format(epoch + 1, avg_train_loss, avg_val_loss, epoch_time))

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            patience_counter = 0
            torch.save(model.state_dict(), model_save_path)
            print('Model saved to {}'.format(model_save_path))
        else:
            patience_counter += 1
            if patience_counter >= patience:  # early stopping
                print('Early stopping triggered at epoch  {}'.format(epoch + 1))
                break

    total_time = time.time() - total_start_time
    print('Total training time: {:.2f} seconds'.format(total_time))

    ''' Plot loss curves '''
    plt.figure()
    plt.plot(range(1, len(train_losses) + 1), train_losses, label='Train Loss')
    plt.plot(range(1, len(val_losses) + 1), val_losses, label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training and Validation Loss Curve')
    plt.legend()
    plt.grid()
    plt.savefig(loss_chart_file)
    print('Chart saved to {}'.format(loss_chart_file))
    # plt.show()

