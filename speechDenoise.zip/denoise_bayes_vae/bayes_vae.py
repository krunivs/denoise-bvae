import torch
import torch.nn.functional as F
from torch import nn
from denoise_bayes_vae.sample import sample_latent


class BayesianLinear(nn.Module):
    """
    Bayesian neural network
    """
    def __init__(self, in_features, out_features, dist_type='gaussian', df=3.0):
        super().__init__()
        self.dist_type = dist_type
        self.df = df
        self.mu_w = nn.Parameter(torch.Tensor(out_features, in_features).normal_(0, 0.1))
        self.logvar_w = nn.Parameter(torch.Tensor(out_features, in_features).normal_(-3, 0.1))
        self.mu_b = nn.Parameter(torch.Tensor(out_features).normal_(0, 0.1))
        self.logvar_b = nn.Parameter(torch.Tensor(out_features).normal_(-3, 0.1))

    def forward(self, x):
        w = sample_latent(self.mu_w, self.logvar_w, self.dist_type, self.df)
        b = sample_latent(self.mu_b, self.logvar_b, self.dist_type, self.df)

        return F.linear(x, w, b)

    def kl_loss(self):
        kl_w = -0.5 * torch.sum(1 + self.logvar_w - self.mu_w.pow(2) - self.logvar_w.exp())
        kl_b = -0.5 * torch.sum(1 + self.logvar_b - self.mu_b.pow(2) - self.logvar_b.exp())

        num_params = self.mu_w.numel() + self.mu_b.numel()

        return (kl_w + kl_b) / num_params  # normalization

class Encoder(nn.Module):
    """
    Encoder for Bayesian VAE(Variational AutoEncoder)
    """
    def __init__(self, input_dim, latent_dim, dist_type='gaussian', df=3.0):
        super().__init__()
        self.dist_type = dist_type
        self.df = df

        self.fc1 = BayesianLinear(input_dim, 512, dist_type, df)
        self.fc2 = BayesianLinear(512, 256, dist_type, df)
        self.fc_mu = nn.Linear(256, latent_dim)
        self.fc_logvar = nn.Linear(256, latent_dim)

        # initialize weight for stable learning
        nn.init.normal_(self.fc_mu.weight, mean=0.0, std=0.01)
        nn.init.constant_(self.fc_mu.bias, 0.0)
        nn.init.normal_(self.fc_logvar.weight, mean=0.0, std=0.01)
        nn.init.constant_(self.fc_logvar.bias, 0.0)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        mu = self.fc_mu(x)
        logvar = self.fc_logvar(x)

        return mu, logvar


class Decoder(nn.Module):
    """
    Decoder for Bayesian VAE(Variational AutoEncoder)
    """
    def __init__(self, latent_dim, output_dim, dist_type='gaussian', df=3.0):
        super().__init__()
        self.dist_type = dist_type
        self.df = df

        self.fc1 = BayesianLinear(latent_dim, 256, dist_type, df)
        self.fc2 = BayesianLinear(256, 512, dist_type, df)
        self.fc_out = nn.Linear(512, output_dim)

    def forward(self, z):
        z = F.relu(self.fc1(z))
        z = F.relu(self.fc2(z))
        out = self.fc_out(z)

        return out


class BayesianVAE(nn.Module):
    """
    Bayesian VAE(Variational AutoEncoder) Model
    """
    def __init__(self, input_dim, latent_dim, dist_type='gaussian', df=3.0):
        """

        :param input_dim: (int) input dimension
        :param latent_dim: (int) latent dimension
        :param dist_type: (str) probability distribution type (either 'gaussian' or 'student_t')
        :param df: (float) degrees of freedom
        """
        super().__init__()
        self.dist_type = dist_type
        self.df = df
        self.encoder = Encoder(input_dim, latent_dim, dist_type, df)
        self.decoder = Decoder(latent_dim, input_dim, dist_type, df)

    def forward(self, x):
        mu, logvar = self.encoder(x)
        z = sample_latent(mu, logvar, self.dist_type, self.df)
        recon_x = self.decoder(z)

        return recon_x, mu, logvar

    def kl_loss(self):
        kl = 0

        for module in self.modules():
            if isinstance(module, BayesianLinear):
                kl += module.kl_loss()

        return kl