# -*- encoding: utf-8 -*-

import os
import torchaudio
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split


class LazySpeechDataset(Dataset):
    """
    Lazy speech noise suppression dataset class
    """
    def __init__(self, noisy_paths, clean_paths, target_sr=16000):
        self.noisy_paths = noisy_paths
        self.clean_paths = clean_paths
        self.target_sr = target_sr
        self.max_len = target_sr

    def __len__(self):
        return len(self.noisy_paths)

    def __getitem__(self, idx):
        noisy, noisy_sr = torchaudio.load(self.noisy_paths[idx])
        clean, clean_sr = torchaudio.load(self.clean_paths[idx])

        # Mono
        if noisy.shape[0] > 1:
            noisy = noisy.mean(dim=0, keepdim=True)
        if clean.shape[0] > 1:
            clean = clean.mean(dim=0, keepdim=True)

        # resampling
        noisy_resampler = torchaudio.transforms.Resample(orig_freq=noisy_sr, new_freq=self.target_sr)
        clean_resampler = torchaudio.transforms.Resample(orig_freq=clean_sr, new_freq=self.target_sr)
        noisy = noisy_resampler(noisy)
        clean = clean_resampler(clean)

        # Slice or pad
        if noisy.shape[1] < self.max_len:
            pad = self.max_len - noisy.shape[1]
            noisy = F.pad(noisy, (0, pad))
            clean = F.pad(clean, (0, pad))
        else:
            noisy = noisy[:, :self.max_len]
            clean = clean[:, :self.max_len]

        return noisy.squeeze(), clean.squeeze()


class SpeechDatasetLoader:
    """
    Speech Denoise Dataset Loader Class to distribute train and validation dataset
    """
    def __init__(self, noisy_dir:str, clean_dir: str,
                 train_val_ratio:float = 0.8,
                 batch_size:int = 16, extension: str = '.wav'):
        """
        Speech Denoise Dataset Loader
        :param noisy_dir: (str) noisy data file directory for training and validation
        :param clean_dir: (str) noisy clean file directory for training and validation
        :param train_val_ratio: (float) train/validation split ratio (default: 0.8) for 80% train, 20% validation
        :param batch_size: (int) batch size
        :param extension: (str) only support wav format
        """
        self.noisy_dir = noisy_dir
        self.clean_dir = clean_dir
        self.extension = extension
        self.train_val_ratio = train_val_ratio
        self.batch_size = batch_size
        self.train_noisy = []
        self.train_clean = []
        self.val_noisy = []
        self.val_clean = []

        if train_val_ratio >= 1:
            raise ValueError('train_val_ratio must be less than 1.')

        self.__split_train_test_files()
        self.train_dataset = LazySpeechDataset(self.train_noisy, self.train_clean)
        self.train_loader = DataLoader(self.train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)

        self.val_dataset = LazySpeechDataset(self.val_noisy, self.val_clean)
        self.val_loader = DataLoader(self.train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)

    def get_train_dataloader(self):
        """
        get train data loader
        :return: (DataLoader)
        """
        return self.train_loader

    def get_val_dataloader(self):
        """
        get validation data loader
        :return: (DataLoader)
        """
        return self.val_loader

    def __split_train_test_files(self):
        """
        split train, test files
        :return:
        """
        noisy_files = sorted([f for f in os.listdir(self.noisy_dir) if f.endswith(self.extension)])
        clean_files = sorted([f for f in os.listdir(self.clean_dir) if f.endswith(self.extension)])
        noisy_paths = []
        clean_paths = []

        if not len(noisy_files):
            raise ValueError('Not found noisy file in {}.'.format(self.noisy_dir))

        if not len(clean_files):
            raise ValueError('Not found clean file in {}.'.format(clean_files))

        if len(noisy_files) != len(clean_files):
            raise ValueError('The number of noise files and clean files is different. '
                             'noisy files:{}, clean files:{}'.format(len(noisy_files), len(clean_files)))

        for noisy_file in noisy_files:
            if noisy_file not in clean_files:
                raise ValueError('Not found clean file. file={}'.format(noisy_file))

            noisy_paths.append(os.path.join(self.noisy_dir, noisy_file))
            clean_paths.append(os.path.join(self.clean_dir, noisy_file))

        print('Total {} input files are found.'.format(len(noisy_files)))

        # split train, test files according to train_val_ratio
        test_size = 1 - self.train_val_ratio
        self.train_noisy, self.val_noisy, self.train_clean, self.val_clean = \
            train_test_split(noisy_paths, clean_paths, test_size=test_size, shuffle=True, random_state=42)

