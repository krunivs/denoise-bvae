# -*- encoding: utf-8 -*-

import torch
import torch.nn.functional as F

def elbo_loss(recon_x, x, mu, logvar, kl_weight=1.0, kl_bayesian=0.0):
    """
    ELBO Loss function with NaN/Inf safety
    """
    # Clamp logvar to avoid overflow in exp()
    logvar = torch.clamp(logvar, min=-10, max=10)

    # MSE reconstruction loss
    recon_loss = F.mse_loss(recon_x, x, reduction='mean')

    # KL divergence for latent variables
    kl_latent = -0.5 * torch.mean(1 + logvar - mu.pow(2) - logvar.exp())

    # Total loss
    total_loss = recon_loss + kl_weight * kl_latent + kl_bayesian

    # print(f"recon_loss: {recon_loss.item():.4f}, kl_latent: {kl_latent.item():.4f}, kl_bayesian: {kl_bayesian:.4f}")

    # Debug print (optional)
    if torch.isnan(total_loss) or torch.isinf(total_loss):
        print("NaN or Inf in loss!", {
            "recon_loss": recon_loss.item(),
            "kl_latent": kl_latent.item(),
            "kl_bayesian": kl_bayesian
        })

    return total_loss